# List a=[1,2,3] mutable
# tuples b=(1,2,3) immutable
# sets c={5,6,7} mutable
# dictinary d={1:'Neel', 2:50, 3:44, 4:'Mulla'} mutable

# string immutable
# array mutable
