# for in loop
"""a = 'Neel'
for i in a:                      # Here, we qre using simple for in lopp
    print(i)

l = [1, 2, 3, 'Neel']            # Here, we are using for in loop with list
for i in l:
    print(i)

t = (1, 3, 6, 8, 0, 'Neel')
for i in t:                     # Here, we are using for in loop with tuple
    print(i)

s = {1, 3, 6, 8, 0, 'Neel'}
for i in s:                     # Here, we are using for in loop with set
    print(i)

d = {2:1, 4:3, 5:6, 7:8, 9:0, 10:'Neel'}
for i in d:                     # Here, we are using for in loop with dictionary
    print(i, d[i])

Suppose if you want print 1000 numbers OR any type of that is larg so, what we do for this so, in PYTHON
their is one function that name is 'range'

for i in range(1, 10):
    print(i)

n = int(input("Enter no:- "))
f = 1
for i in range(1, n+1) :
    f = f * i
    print(f)"""

n = int(input("Enter Number "))
c = 0
for i in range(2, n) :
        if(n%i==0) :
            c = c + 1
if (c == 0) :
    print("Prime No")
else :
    print("Not prime")