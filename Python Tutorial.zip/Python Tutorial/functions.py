"""
def xyz(x):
    if(x%2==0):
        #print("Even no")
        return x
    else:
        #print("odd no")
        return x + 1
n = int(input("Enter no"))
y = xyz(n)
print(y)


# factorial program using function

def fact(x):
    f = 1
    for i in range(1, x+1):
        f = f * i
    return f
n = int(input("Enter no "))
factorial = fact(n)
print(factorial)
"""

# Addition program using function

def add (x, y):
    c = x + y
    print(c)

def sub (x, y):
    d = x - y
    print(d)
x = int(input("Enter x "))
y = int(input("Enter y "))

add(x, y)
sub(x, y)