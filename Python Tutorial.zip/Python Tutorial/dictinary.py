# Mutable data type
# Key: value pair

a = {}
print(a)

d = {1:'NeeL', 3:'Mulla', 8:30}
print(d)

d1 = {'Neel':30, 'Mulla':50}
print(d1)

f = {1:[2, 3, 4, 5]}
print(f)

d2 = dict({1:[5,'Neel', 8, 'Mulla']})
print(d2)

d3 = dict([(1, 'for'), (2, 'Hello')])
print(d3)

d4 = {1:'Neel', 2:60, 3:{4:99, 5:88}}
print(d4)

d4[6] = 'Mulla'
print(d4)

d4[3] = 'Change'
print(d4)

print(d4[1])
print(d4[6])

print(d4.get(2))


del d4[2]
print(d4)

d5 = d4.copy()
print(d5)

print(d5.keys())

print(d5.items())