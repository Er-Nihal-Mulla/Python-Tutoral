# List requires more memory

a = ['Neel', 'Mulla', 24, 2.4]
print(a)
print(a[1])
print(a[3])
print(a[1:3])
print(a[-1])

b = [30, 55, 'Youtube']
print(b[-1])

c = [a, b]
print(c)

b.insert(3, 'Nihal')
print(b)

a.remove(2.4)
print(a)

a.pop(2)
print(a)

a.append(2.4)
print(a)

a.pop()
print(a)
print(b)

del b[1:2]
print(b)

# b.remove(1)
# print(b)

b.extend([11, 44, 99])
print(b)

d = {10, 88, 44, 66}
e = max(d)
print(e)


f = ['NeeL', 'Mulla', 'Maha', 'India']
g = max(f)
print(g)

