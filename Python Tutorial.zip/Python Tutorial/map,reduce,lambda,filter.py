"""lambda function - 1) basically lambda function is used for to define one line function
                     2) In lambda() function their you will not need to define any return statement also
                        and any extra function also
def xyz(a, b):
    return a + b


n = int(input("Enter A "))
m = int(input("Enter B "))
c = xyz(n, m)
print(c)

#We write this above program using lambda() function

c = lambda a, b : a + b

n = int(input("Enter A "))
m = int(input("Enter B "))
print(c(n, m))


#map function - In order to apply same function over sequence
def xyz(n):
    return n * n
l = [2, 4, 7]
c = map(xyz, l)
print(list(c))


#We write this above program using lambda() function
d = lambda n:n*n
l = [2,4,7]
c = map(d, l)
print(tuple(c))


c = [2,4,6]
d = [2,6,9]

def mul(x, y):
    return x*y
a = map(mul, c,d)
print(list(a))
"""


# filter(a,b)    a:function to be applied on a   b:sequence

def xyz(n):
    if n % 2 == 0:
        return True
    else:
        return False


l = [1, 2, 4, 5, 8, 9]

c = filter(xyz, l)
print(list(c))
