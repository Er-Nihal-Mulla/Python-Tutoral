# For tuples, it requires less memory as comparison List

import sys

t = (10, 55, 44, 'Neel', 'Mulla')
print(t)
print(t[1])

# print(t[5])
# t[1]=50
print(len(t))
print(dir(t))

print(sys.getsizeof(t))

t = [10, 55, 44, 'Neel', 'Mulla']
print(sys.getsizeof(t))

t = tuple("NeeL")
print(t)
t = tuple()
print(t)

#how to merge tuples
a = (10, 20, 30)
b = (40, 50, 60)

c = (a, b)
print(c)
c = a + b
print(c)

t = tuple('Neel')
print(t)

print(t[1:])
print(t[-1])

print(t[::-1])