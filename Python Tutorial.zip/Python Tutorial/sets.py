# Set is an data type and it's an un-order collection of data type
# Set is mutable(you can change the values by using assignment operator)
# Immutable means you can not change the values
# There is no duplicate value exist


a = {1, 2, 3, 'NeeL', 'Mulla'}
print(a)

a = set('NeeL')
print(a)

a.update([11, 22, 33])
print(a)

a.remove(11)
print(a)

a.discard(22)
print(a)

a.pop()
print(a)

a.clear()
print(a)

a = {22, 55, 88, 66}
print('A=', a)
b = a.copy()
print("B=", b)


#frozenset

s = {1, 4, 2, 5}
print(s)

s1 = frozenset(s)
print(s1)

s.add(44)
print(s)