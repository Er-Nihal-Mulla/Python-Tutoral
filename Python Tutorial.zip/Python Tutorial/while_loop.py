# while loop
# while else loop
# pass statement

"""
    # while loop

i = 0
c = 2
while (i < 2) :
    print("Hello")
    i = i + 2

n = int(input("Enter no "))
f = 1
i = 1
while (i<=n) :
    f = f * i
    i = i + 1
    print(f)

    # while else loop

m = 1
n = 5
while (m <= 5):
    if (m == n) :
        print("out of while")
        break
    print(m)
    m = m + 1
else:
    print("no break statement, else statement")"""


    # pass statement
""" 1) pass statement means, suppose if you want write some code but dont want to print anything from this code
so, here you will use the pass statement 
2) pass statement it's looks like a NULL statement
"""
# Example:-

for i in 'NeeL' :
     pass
print("Hello")
