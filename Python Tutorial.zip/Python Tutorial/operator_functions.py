import operator

n = int(input("Enter First Value"))
m = int(input("Enter Second Value"))
c = operator.add(n, m)
print(c)

d = operator.sub(n, m)
print(d)

e = operator.mul(n, m)
print(e)

f = operator.truediv(n, m)
print(f)

g = operator.floordiv(n, m)
print(g)

h = operator.mod(n, m)
print(h)

i = operator.pow(n, m)
print(i)

if (operator.gt(n, m)):     #Here, lt means 'less than'  And gt means 'greater  And ge means greater than equal to And le means less than equal to And eq means equals to
    print("n is less than m")
else:
    print('m is less than n')