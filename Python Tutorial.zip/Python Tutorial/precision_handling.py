# Inbuilt functions through we can perform precision handling in python

import math

d = 5.81234
print(math.trunc(d))  # trunc() function returns the integer value
print(math.ceil(d))   # ceil() function returns the nearest greater value
print(math.floor(d))  # floor() function return the nearest smaller value

# round() function used for to find round of values
print(round(d, 2))          #1
print('%.3f' %d)            #2
print("{0:.4f}".format(d))  #3