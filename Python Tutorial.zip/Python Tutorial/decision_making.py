# if else
# if elseif else
# Nested if else

"""
if(condition):
    print("Hello")
else:
    print("Bye")
"""

a = 10
b = 20

if (a < b):
    print("A is greater")
else:
    print("B is greater")


x = 30
y = 30
z = 20

if(x > y):
    print("X is Greater than y & z")
elif(x > z):
    print("X is greater than z")
elif(y > x):
    print("y is greater than x")
elif(y > z):
    print("y is greater than z")
    