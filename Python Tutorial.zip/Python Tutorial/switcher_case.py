# switcher case    In python also we call dictionary mapping to switcher case
def a():
    return "hello"
def b():
    return "bye"
def xyz (x) :
    switcher = {
        1:a(),
        2:b()
    }
    return switcher.get(x, "Option not available")
n = int(input("Enter choice"))
c = xyz(n)
print(c)