#A module defines functions, classes, variables
#"import" statement
#"from import" statement
#math module, random module, time module, date time module, caleder module, PyAutoGui module,
#Pyqrcode module, struct module, Urllib module, etc.

