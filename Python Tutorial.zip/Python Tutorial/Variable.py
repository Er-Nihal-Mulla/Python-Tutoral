# -*- coding: utf-8 -*-
"""
Created on Mon May  4 16:05:07 2020

@author: NeeL
"""


print("Welcome to Python Variables")

x=3+2
print(x)

c=3-2
print(c)

a=3*2
print(a)

d=3/2
print(d)
print("To print value in a integer by using // (Double divisible operator)")
d=3//2
print(d)

b=2**3
print(b)

n=4%3
print(n)


print("To Print String")

n='Nihal'
print(n)
print("In python you can print the string using single code also and double code also")
m="Nihal"
print(m)

h="Nihal " + " Mulla"
print(h)

u=2*"Nihal Mulla"
print(u)

print("Now we wants to know type of the variable")
y=3.14
print(type(y))

z=5
print(type(z))

r="Nihal"
print(type(r))


x=2
y=3
c=x+y
print(c)
s=c+y
print(s)

print("Now here we use \n\t")
print("Nihal \n Mulla")
print("Nihal \t Mulla")

print("To get the address of the variable")
n=9
print(id(n))

m=9
print(id(m))



