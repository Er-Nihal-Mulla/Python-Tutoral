# python script

""" Python script
 Airtel jindabad"""

"""x = float(input("Enter First Number:- "))
y = float(input("Enter Second Number:- "))
z = x + y
print(z)
print(type(z))"""

"""a, b, c = input("Enter Values ").split()     #The split() is use for to take inout from user in a single line
print("Value os A {} & Value of B {} & Value of C {}".format(a, b, c))  
print("Value of A: ", a)
print("Value of B: ", b)
print("Value of C: ", c)
"""

a1, b1 = input("Enter Values").split()

a = int(a1)
b = int(b1)

c = a + b

d = a - b

e = a / b

f = a * b

print("The addition is {} & The Substraction is {} & The Division is {} & The Multiplication is {} ".format(c, d, e, f) )