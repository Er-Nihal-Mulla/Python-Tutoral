# Assignment operators (+ - / * % //)
# Relational operator (< > <= >= == != )
# Logical operator (and or not)
# Bitwise operator (& ! ~ ^ >> <<)
# Assignment operator (= += -= *= /= %= //=  **= &= |= ^= >>= <<=)
#   Special operators (Identity, membership)
#       Identity operator (is, is not)
#       Membership operator (in, not in)

a = int(input("Enter value of a "))
b = int(input("Enter value of b "))

c = a + b
print("Addition is ", end='')
print(c)

d = a - b
print("Subtraction is ", end='')
print(d)

e = a * b
print("Multiplication is ", end='')
print(e)

f = a / b
print("Division is ", end='')
print(f)

g = a // b
print("Division floor is ", end='')
print(g)

h = a % b
print("Modulus is ", end='')
print(h)

